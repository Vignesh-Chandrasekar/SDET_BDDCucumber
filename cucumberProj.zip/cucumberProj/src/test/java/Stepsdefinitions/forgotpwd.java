package Stepsdefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;

public class forgotpwd {

	WebDriver driver = null;
	@Given("User is on login page")
	public void user_is_on_login_page() {

		String projectPath = System.getProperty("user.dir");
		System.out.println("Project path is:"+projectPath);	
		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to("https://www.gillette.co.in/en-in/loginpage");
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
	}

	@When("user enters username")
	public void user_enters_username() {
		System.out.println("Inside step - user is on login page");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_username\"]")).sendKeys("vignesh.india88@gmail.com");
		

	}

	@And("clicks on forgot password link")
	public void clicks_on_forgot_password_link() {
		System.out.println("Inside step - user clicks on forgot password link");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_forgotpassword\"]")).click();

	}

	@When("user is navigated to the forgot password link")
	public void user_is_navigated_to_the_forgot_password_link() {
		System.out.println("Inside step - user navigated to forgot password link");
	}

	@And("User provides email ID")
	public void user_provides_email_id() {
		System.out.println("Inside step - user provides email ID");

		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_username\"]")).sendKeys("vignesh.india88@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_Create Your New Password\"]")).click();
	}

	@Then("User resets Password")
	public void user_resets_password() {
		System.out.println("Inside step - user resets Password");
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
		driver.close();
		driver.quit();
		
	}


	
}
