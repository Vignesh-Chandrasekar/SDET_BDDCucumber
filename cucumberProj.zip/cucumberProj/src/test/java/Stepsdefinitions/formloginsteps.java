package Stepsdefinitions;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;

public class formloginsteps {

	WebDriver driver = null;
	@Given("user is on login page")
	public void user_is_on_login_page() {

		System.out.println("Inside Step - user is on login page");
		String projectPath = System.getProperty("user.dir");
		System.out.println("Project path is:"+projectPath);	
		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.navigate().to("https://www.gillette.co.in/en-in/loginpage");
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		
	}

	@When("user enters username and password")
	public void user_enters_username_and_password() {
		
		System.out.println("Inside Step - user enters username and password");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_username\"]")).sendKeys("vignesh.india88@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_Container\"]/div[2]/input")).sendKeys("vicky3611");
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		
	}

	@And("clicks on login button")
	public void clicks_on_login_button() {
		
		System.out.println("Inside Step - clicks on login button");
		//driver.findElement(By.className("button-link button")).click();
		driver.findElement(By.id("phdesktopbody_0_Sign In")).click();
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		driver.navigate().refresh();
		
	}

	@Then("user is navigated to the home page")
	public void user_is_navigated_to_the_home_page() {
		
		System.out.println("Inside Step - user is navigated to the home page");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
		driver.close();
		driver.quit();
		
	}


}
