package Stepsdefinitions;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;



public class register {
	
	WebDriver driver = null;
	@Given("user launches browser")
	public void user_launches_browser() {
		System.out.println("Inside step - user launches browser");	
		
		
		String projectPath = System.getProperty("user.dir");
		System.out.println("Project path is:"+projectPath);	
		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
	}

	@When("User opened the homepage link")
	public void user_opened_the_homepage_link() {

		System.out.println("Inside step - user is on browser page");	
		
		driver.navigate().to("https://www.gillette.co.in/");
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//*[@id=\"desk-country-selector\"]/div/a")).sendKeys("India English");
	}

	@And("user clicks on Register button")
	public void user_clicks_on_register_button() {
		System.out.println("Inside step - user clicks on Register button");	
		//driver.findElement(By.xpath("//*[@id=\"phdesktopheader_0_phdesktopheadertop_2_pnlCRMHeaderLink\"]/div/a[2]")).click();
		driver.findElement(By.className("event_profile_register")).click();
	}

	@When("User enters profile details")
	public void user_enters_profile_details() {
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[firstname]\"]")).sendKeys("Vignesh");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[lastname]\"]")).sendKeys("Chandrasekar");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[emails][0][address]\"]")).sendKeys("vignesh.tyr@yahoo.com");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[password][password]\"]")).sendKeys("vicky3611");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[password][confirm]\"]")).sendKeys("vicky3611");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][month]\"]")).sendKeys("10");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][year]\"]")).sendKeys("1989");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[addresses][0][postalarea]\"]")).sendKeys("621010");
		
	}

	@And("clicks on Create your profile button")
	public void clicks_on_create_your_profile_button() {
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_submit\"]")).sendKeys(Keys.ENTER);
	}

	@Then("user is registered successfully")
	public void user_is_registered_successfully() {
		System.out.println("User registered successfully");
		driver.close();
		driver.quit();
	}



}
