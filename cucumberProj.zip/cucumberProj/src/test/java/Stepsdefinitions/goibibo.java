package Stepsdefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;

public class goibibo {

	WebDriver driver = null;
	@Given("user launch goibibo website")
	public void user_launch_goibibo_website()  {

		String projectPath = System.getProperty("user.dir");
		System.out.println("Project path is:"+projectPath);	
		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.navigate().to("https://www.goibibo.com/");
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		
		
	}

	@When("select one way trip")
	public void select_one_way_trip() throws InterruptedException {
		System.out.println("Inside step - user selects one way option");
		driver.findElement(By.xpath("//*[@id=\"oneway\"]")).click();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				
	}

	@And("select from and destination")
	public void select_from_and_destination() throws InterruptedException {
		System.out.println("Inside step - user selects Source and Destination");
		//driver.findElement(By.xpath("//*[@id=\"gosuggest_inputSrc\"]")).sendKeys("Chennai (MAA)");
		//driver.findElement(By.xpath("//*[@id=\"gosuggest_inputDest\"]")).sendKeys("Bengaluru (BLR)");
		
		driver.findElement(By.xpath("//*[@id=\"gosuggest_inputSrc\"]")).sendKeys("Chennai");
		driver.findElement(By.xpath("//*[@id=\"gosuggest_inputDest\"]")).sendKeys("Bengaluru");
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
	}

	@When("select departure date")
	public void select_departure_date() throws InterruptedException {
		System.out.println("Inside step - user selects Departure date");
		driver.findElement(By.xpath("//*[@id=\"departureCalendar\"]")).click();
		driver.findElement(By.xpath("//span[contains(@class,'DayPicker-NavButton DayPicker-NavButton--next')]")).click();
		driver.findElement(By.xpath("//div[@id='fare_20200925']")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
	}

	@And("User provides traveller details and travel class")
	public void user_provides_traveller_details_and_travel_class() throws InterruptedException {
		System.out.println("Inside step - user selects traveller details and traveller class");
		driver.findElement(By.xpath("//*[@id=\"adultPaxBox\"]']")).click();
		driver.findElement(By.xpath("//*[@id=\"adultPaxPlus\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"gi_class\"]")).sendKeys("Economy");
		driver.findElement(By.xpath("//*[@id=\"gi_search_btn\"]")).sendKeys(Keys.ENTER);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
	}

	@When("user checked for cheapest price")
	public void user_checked_for_cheapest_price() throws InterruptedException {
		System.out.println("Inside step - user checks for cheapest price");
		driver.findElement(By.xpath("//*[@id=\"PRICE\"]/span/span")).click();
		
	}

	@And("click on Book button")
	public void click_on_book_button() throws InterruptedException {
		System.out.println("Inside step - user clicks on Book button");
		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/div[2]/div[2]/div[2]/div[2]/div[2]/div[1]/div/div/div[1]/div[2]/span/span/input")).click();
		
	}

	@Then("User navigated to booking page and reviews the option")
	public void user_navigated_to_booking_page_and_reviews_the_option() {
		System.out.println("Inside step - user reviews the booking details");
		driver.close();
		driver.quit();
	}


	
}
